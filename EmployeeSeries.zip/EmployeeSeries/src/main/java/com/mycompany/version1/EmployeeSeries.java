/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.version1;

/**
 *
 * @author Josh
 */
public class EmployeeSeries {

    public static void main(String[] args) {
        HourlyEmployee jans = new HourlyEmployee(42,100,"jans",101);
        System.out.println(jans.computeSalary());
        PieceWorkerEmployee josh = new PieceWorkerEmployee(500,10,"josh",102);
        System.out.println(josh.computeSalary());
        ComissionEmployee jio = new ComissionEmployee(15000,"jio",103);
        System.out.println(jio.computeSalary());
        BasedPlusCommissionEmployee dusky = new BasedPlusCommissionEmployee(15000,15000 ,"dusky",104);
        System.out.println(dusky.computeSalary());
    }
}
